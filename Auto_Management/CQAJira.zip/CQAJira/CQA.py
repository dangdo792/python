import requests
import os
import re
import json
import main
import Events
import logging

try:
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET

module_logger = logging.getLogger(__name__)


class CQA:
    def __init__(self, _methodReq, _usr, _pwd, _recordID=None, _data=None):  # Data is dictionary
        self.methodReq = _methodReq
        self.usr = _usr
        self.pwd = _pwd
        self.recordID = _recordID
        self.data = _data
        self.events = Events.Events()
        if self.methodReq == 'GET':
            self.getRequest()
        elif self.methodReq == 'PUT':
            self.putRequest()
        elif self.methodReq == 'POST':
            self.postRequest()
        else:
            module_logger.info('Method is invalid')

    @staticmethod
    def translate_xml(line):
        line = line.replace('%', '%25')
        line = line.replace('\n', '%0D%0A')
        line = line.replace(' ', '%20')
        line = line.replace("\\", '%5C')
        line = line.replace("/", '%2F')
        line = line.replace(":", '%3A')
        line = line.replace("[", '%5B')
        line = line.replace("]", '%5D')
        line = line.replace('#', '%23')
        line = line.replace('&', '%26')
        line = line.replace('|', '%7C')
        line = line.replace('*', '%2A')
        line = line.replace("@", '%40')
        return line

    def repairLink(self):
        _link = ''
        if self.methodReq == 'POST':
            _link = main.URL_CQA
        else:
            if self.recordID is not None:
                _link = main.URL_CQA + '/' + self.recordID
            else:
                module_logger.info(self.recordID)
        return _link

    def repairDATA(self):
        if self.methodReq == 'GET':
            self.events.toAsciiXML(self.pwd)
            _data = '?format=XML&recordType=Action&autoSave=false' + \
                    '&loginId=' + self.usr + \
                    '&password=' + self.events.toAsciiXML(self.pwd) + \
                    '&noframes=true'
        elif self.methodReq == 'PUT':
            _status = False
            with open('updateCQA.json', 'r') as f:
                dataSend = json.load(f)
                _status = True
            f.close()
            if _status:
                _data = '?format=XML&recordType=Action&action=Modify&fieldsXml=' + \
                    '<Field><Name>Changed_items</Name><Value><![CDATA[' + self.translate_xml(dataSend['Changed_items']) + ']]></Value></Field>' + \
                    '<Field><Name>Information_field</Name><Value><![CDATA[' + self.translate_xml(dataSend['Information_field'])+ ']]></Value></Field>' + \
                    '<Field><Name>Mail_cc_multiline</Name><Value><![CDATA[' + self.translate_xml(dataSend['Mail_cc_multiline']) + ']]></Value></Field>' + \
                    '<Field><Name>Mail_subject</Name><Value><![CDATA[' + self.translate_xml(dataSend['Mail_subject']) + ']]></Value></Field>' + \
                    '<Field><Name>Mail_to_multiline</Name><Value><![CDATA[' + self.translate_xml(dataSend['Mail_to_multiline']) + ']]></Value></Field>' + \
                    '<Field><Name>SSM_response_details</Name><Value><![CDATA[' + self.translate_xml(dataSend['SSM_response_details']) + ']]></Value></Field>' + \
                    '<Field><Name>Status</Name><Value><![CDATA[' + self.translate_xml(dataSend['Status']) + ']]></Value></Field>' + \
                    '&autoSave=true&loginId=' + self.translate_xml(dataSend['loginId']) + '&password=' + self.translate_xml(dataSend['password']) + '&noframes=true'
        elif self.methodReq == 'POST':
            with open('updateCQA.json', 'r') as f:
                dataSend = json.load(f)
            f.close()
            _data = '?format=XML&recordType=Action&fieldsXml=' + \
                    '<Field><Name>Product</Name><Value><![CDATA[' + self.translate_xml(dataSend['Product']) + ']]></Value></Field>' + \
                    '<Field><Name>Customer</Name><Value><![CDATA[' + self.translate_xml(dataSend['Customer']) + ']]></Value></Field>' + \
                    '<Field><Name>Model</Name><Value><![CDATA[' + self.translate_xml(dataSend['Model']) + ']]></Value></Field>' + \
                    '<Field><Name>Subproject</Name><Value><![CDATA[' + self.translate_xml(dataSend['Subproject']) + ']]></Value></Field>' + \
                    '<Field><Name>Release_version</Name><Value><![CDATA[' + self.translate_xml(dataSend['Release_version']) + ']]></Value></Field>' + \
                    '<Field><Name>Responsible</Name><Value><![CDATA[' + self.translate_xml(dataSend['Responsible']) + ']]></Value></Field>' + \
                    '<Field><Name>Originator</Name><Value><![CDATA[' + self.translate_xml(dataSend['Originator']) + ']]></Value></Field>' + \
                    '<Field><Name>Kind</Name><Value><![CDATA[' + self.translate_xml(dataSend['Kind']) + ']]></Value></Field>' + \
                    '<Field><Name>Short_description</Name><Value><![CDATA[' + self.translate_xml(dataSend['Short_description']) + ']]></Value></Field>' + \
                    '<Field><Name>Detailed_description</Name><Value><![CDATA[' + self.translate_xml(dataSend['Detailed_description']) + ']]></Value></Field>' + \
                    '<Field><Name>Customer_relevance</Name><Value><![CDATA[' + self.translate_xml(dataSend['Customer_relevance']) + ']]></Value></Field>' + \
                    '<Field><Name>Defect_kind</Name><Value><![CDATA[' + self.translate_xml(dataSend['Defect_kind']) + ']]></Value></Field>' + \
                    '<Field><Name>Defect_cause_process</Name><Value><![CDATA[' + self.translate_xml(dataSend['Defect_cause_process']) + ']]></Value></Field>' + \
                    '<Field><Name>Defect_detect_process</Name><Value><![CDATA[' + self.translate_xml(dataSend['Defect_detect_process']) + ']]></Value></Field>' + \
                    '<Field><Name>Defect_detection_date</Name><Value><![CDATA[' + self.translate_xml(dataSend['Defect_detection_date']) + ']]></Value></Field>' + \
                    '<Field><Name>Defect_repeated</Name><Value><![CDATA[' + self.translate_xml(dataSend['Defect_repeated']) + ']]></Value></Field>' + \
                    '<Field><Name>Origin</Name><Value><![CDATA[' + self.translate_xml(dataSend['Origin']) + ']]></Value></Field>' + \
                    '<Field><Name>Status</Name><Value><![CDATA[' + self.translate_xml(dataSend['Status']) + ']]></Value></Field>' + \
                    '&autoSave=true&loginId=' + self.translate_xml(dataSend['loginId']) + '&password=' + self.translate_xml(dataSend['password']) + '&noframes=true'

        else:
            # Do nothing
            _data = None
        return _data

    # GET
    def getRequest(self):
        module_logger.info('GET')
        _status = False
        _url = self.repairLink() + self.repairDATA()
        resp = requests.get(_url)
        with open('getCQA.xml', 'wb') as f:
            f.write(resp.content)
            _status = True
        f.close()
        if _status:
            tree = ET.parse('cqa.xml')
            root = tree.getroot()
            namespace = {'ns': "http://ibm.com/rational/clearquest/web/v7.1"}
            retGet = {
                'Product': '',
                'Customer': '',
                'Model': '',
                'Subproject': '',
                'Release_version': '',
                'Responsible': '',
                'Origin': '',
                'Originator': '',
                'Status': '',
                'Short_description': '',
                'Detailed_description': ''
            }
            with open(self.recordID +'_Info.txt', 'wb') as file:
                for key in retGet.keys():
                    findIn = './/ns:field[ns:fieldname="' + key + '"]/ns:value'
                    for val in root.iterfind(findIn, namespace):
                        retGet[key] = val.text
                        if key == 'Detailed_description':
                            retGet[key] = retGet[key][1:-1]
                            retGet[key] = re.sub(u'(["][,])|(["])','',retGet[key])
                            retGet[key] = re.sub(u'[\\\]', '', retGet[key])

                        break
                    flinecontent = '{:<25}{:^3}{:<10}'.format(key, ':', retGet[key]) + '\n'
                    file.write(bytes(flinecontent))
            os.remove('getCQA.xml')
        else:
            module_logger.info('ERROR ...............' + _url)
            return _status

    # PUT/EDIT
    # daft CQA: nprod00666409, nprod00671929, nprod00671942
    def putRequest(self):
        module_logger.info('PUT/EDIT')
        from urllib.request import urlopen
        _url = self.repairLink() + self.repairDATA()
        response = urlopen(_url)
        resp_xml = response.read()
        s = str(resp_xml)
        resp = s[s.find('<cqModifyResult>') + len('<cqModifyResult>'):s.rfind('</cqModifyResult>')]
        if resp == 'ok':
            module_logger.info('OK ..................' + str(resp))
        else:
            module_logger.debug('ERROR ...............' + str(resp))

    # POST/CREATE
    def postRequest(self):
        module_logger.info('POST')
        from urllib.request import urlopen
        _url = self.repairLink() + self.repairDATA()
        response = urlopen(_url)
        resp_xml = response.read()
        s = str(resp_xml)
        resp = s[s.find('<recordId>') + len('<recordId>'):s.rfind('</recordId>')]
        print('resp ....................', resp)
        if 'nprod' in resp:
            module_logger.info('OK ..................' + str(resp))
        else:
            module_logger.debug('ERROR ...............' + str(resp))
        # with open('createCQA.xml', 'wb') as f:
        #     f.write(resp_xml)
        # f.close()