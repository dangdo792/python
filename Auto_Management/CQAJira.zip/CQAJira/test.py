import http.client as Client

dataSend = {'Changed_items': 'tamtit',
                        'Information_field': r'<SWMRS> https://rb-alm-13-p-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-4147106800294823-V-94-000a3e40-100000a?doors.view=00000009 Baseline:7.6\r\n' +
                                             r'<SWMTS> https://rb-alm-13-p-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-4147106800294823-V-230-000a3e42-1000006?doors.view=00000014 Baseline:3.5\r\n' +
                                             r'<Module Test Result> https://inside-ilm.bosch.com/irj/go/nui/sid/90ac75a7-6136-3610-61b6-f4a3e96d966f\r\n' +
                                             r'<OPL Link> No\r\n' +
                                             r'<Code Coverage>C1: 100%\r\n' +
                                             r'<Code Coverage Exception> No\r\n' +
                                             r'<Defect CQA> No',
                        'Mail_cc_multiline': r'Tam.NguyenTrong2@vn.bosch.com; Tam.NguyenTrong2@vn.bosch.com; Tam.NguyenTrong2@vn.bosch.com; Tam.NguyenTrong2@vn.bosch.com; Tam.NguyenTrong2@vn.bosch.com',
                        'Mail_subject': r'[Delivery-Module Test][FIAT_334-MY19]fus_x_mon',
                        'Mail_to_multiline': r'Tam.NguyenTrong2@vn.bosch.com',
                        'SSM_response_details': r'-File Name: \sources\comps\fus\cpc\fus_x_mon\fus_x_mon.c\r\n' +
                                                r'-CP: 1.9.1.422.2.4.1.20.2.107.3.7.2.24\r\n' +
                                                r'-Revision: 1.4.2.8.3.5\r\n' +
                                                r'-Total lines of code: 88\r\n' +
                                                r'\n' +
                                                r'-ELOC (tested lines): 14\r\n' +
                                                r'-No. of requirements tested: 8\r\n' +
                                                r'-No. of requirements not tested: 0\r\n',
                        'Status': 'assigned',
                        'loginId': 'nat2hc',
                        'password': 'BeInvestor#1236'
                        }
# _data = '?format=HTML&recordType=Action&action=Modify&fieldsXml=' + \
_data = 'recordType=Action&action=Modify&fieldsXml=' + \
        '<Field><Name>Changed_items</Name><Value><![CDATA[' + dataSend['Changed_items'] + ']]></Value></Field>' + \
        '<Field><Name>Information_field</Name><Value><![CDATA[' + dataSend['Information_field'] + ']]></Value></Field>' + \
        '<Field><Name>Mail_cc_multiline</Name><Value><![CDATA[' + dataSend['Mail_cc_multiline'] + ']]></Value></Field>' + \
        '<Field><Name>Mail_subject</Name><Value><![CDATA[' + dataSend['Mail_subject'] + ']]></Value></Field>' + \
        '<Field><Name>Mail_to_multiline</Name><Value><![CDATA[' + dataSend['Mail_to_multiline'] + ']]></Value></Field>' + \
        '<Field><Name>SSM_response_details</Name><Value><![CDATA[' + dataSend['SSM_response_details'] + ']]></Value></Field>' + \
        '<Field><Name>Status</Name><Value><![CDATA[' + dataSend['Status'] + ']]></Value></Field>' + \
        '&autoSave=true&loginId=' + dataSend['loginId'] + '&password=' + dataSend['password'] + '&noframes=true'


# http://si0bos201.de.bosch.com/cqweb/restapi/CQ2012prod/nprod/RECORD/nprod00666409
def chunk_data(data, chunk_size):
    dl = len(data)
    ret = ""
    for i in range(dl // chunk_size):
        ret += "%s\r\n" % (hex(chunk_size)[2:])
        ret += "%s\r\n\r\n" % (data[i * chunk_size : (i + 1) * chunk_size])

    if len(data) % chunk_size != 0:
        ret += "%s\r\n" % (hex(len(data) % chunk_size)[2:])
        ret += "%s\r\n" % (data[-(len(data) % chunk_size):])

    ret += "0\r\n\r\n"
    return ret


# http://si0bos201/cqweb/
host = 'http://si0bos201.de.bosch.com/'
conn = Client.HTTPConnection(host)
url = "/cqweb/restapi/CQ2012prod/nprod/RECORD/nprod00666409"
conn.putrequest('POST', url)
conn.putheader('Transfer-Encoding', 'chunked')
conn.endheaders()
# conn.send(chunk_data(body, size_per_chunk).encode('utf-8'))
conn.send(chunk_data(_data, 200).encode('utf-8'))

resp = conn.getresponse()
print(resp.status, resp.reason)
conn.close()
