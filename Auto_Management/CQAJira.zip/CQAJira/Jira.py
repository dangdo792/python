import json
import os
import requests
import logging
import main
import Events

module_logger = logging.getLogger(__name__)


class Jira:

    def __init__(self, _methodReq, _recordID=None, _data=None):  # Data is json file
        self.session = requests.Session()
        self.methodReq = _methodReq
        self.recordID = _recordID
        self.data = _data
        self.Events = Events.Events()
        if self.methodReq == 'GET':
            self.getRequest()
        elif self.methodReq == 'PUT':
            self.putRequest()
        elif self.methodReq == 'POST':
            self.postRequest()
        else:
            module_logger.error('Method is invalid')

    def repairLink(self):
        _link = None
        if self.methodReq == 'POST':
            _link = main.URL_JIRA
        else:
            if self.recordID is not None:
                _link = main.URL_JIRA + '/' + self.recordID
            else:
                module_logger.error("recordID ERROR: " + str(self.recordID))
        return _link

    def repairDATA(self):
        if self.methodReq == 'GET':
            _data = None
        elif self.methodReq == 'PUT' or self.methodReq == 'POST':
            with open('updateJira.json', 'r') as f:
                _data = json.load(f)
            f.close()
        else:
            # Do nothing
            _data = None
        return _data

    # Login
    def logIn(self):
        from requests_kerberos import HTTPKerberosAuth, OPTIONAL
        auth = HTTPKerberosAuth(mutual_authentication=OPTIONAL)
        url = main.URL_JIRA_LOGIN
        response = self.session.post(url, verify=True, auth=auth)
        if response.status_code in (405, 403):
            module_logger.info('LOGIN OK')
            return True
        else:
            module_logger.info('Cannot login JIRA')

    # GET
    def getRequest(self):
        module_logger.info('GET')
        _response = None
        _status = False
        _url = self.repairLink()
        for timesReq in range(3):
            _response = self.session.get(_url)
            if _response.status_code == 401:
                module_logger.info('Authorization........' + str(_response.status_code))
                self.logIn()
            elif _response.status_code == 200:
                module_logger.info('OK ..................' + str(_response.status_code))
                module_logger.debug('OK ..................' + _response.content)
                break
            else:
                module_logger.debug('ERROR...............' + str(_response.status_code))
                break
        if _response is not None:
            with open('getJira.json', 'wb') as f:
                f.write(_response.content)
                _status = True
            f.close()
        if _status:
            module_logger.info('De-parsing Data......')
            json_data = open('getJira.json').read()
            jdata = json.loads(json_data)
            # Bug: That each project have its specific JIRA format
            # Current: based on JIRA of BEGEORAO
            retGet = {
                'summary': jdata['fields']['summary'],
                'priority': jdata['fields']['priority']['name'],
                'versions': jdata['fields']['versions'][0]['name'],
                'components': jdata['fields']['components'][0]['name'],
                'status': jdata['fields']['status']['name'],
                'resolution': jdata['fields']['resolution']['name'],
                'fixVersions': jdata['fields']['fixVersions'][0]['name'],
                'assigneeName': jdata['fields']['assignee']['displayName'],
                'assigneeEmail': jdata['fields']['assignee']['emailAddress'],
                'reporterName': jdata['fields']['reporter']['displayName'],
                'reporterEmail': jdata['fields']['reporter']['emailAddress'],
                'duedate': jdata['fields']['duedate'],
                'created': jdata['fields']['created'],
                'Updated': jdata['fields']['updated'],
                'description': jdata['fields']['description'],
                'comments': list(zip(set(self.Events.findKeyInDict('displayName', jdata['fields']['comment'])),
                                     list(self.Events.findKeyInDict('body', jdata['fields']['comment']))))
            }
            with open(self.recordID + '_Info.txt', 'w') as file:
                for key in retGet.keys():
                    flinecontent = ''
                    if key == 'comments':
                        for name, content in retGet[key]:
                            flinecontent = '{:<25}{:^3}{:<10}'.format(name, ':', content) + '\n'
                    else:
                        flinecontent = '{:<25}{:^3}{:<10}'.format(key, ':', retGet[key]) + '\n'
                    file.write(flinecontent)
            os.remove('getJira.json')

    # PUT/EDIT
    def putRequest(self):
        module_logger.info('PUT/EDIT')
        _url = self.repairLink()
        data = self.repairDATA()
        headers = {'Content-Type': 'application/json', 'Accept': 'application/json'}
        for timesReq in range(3):
            _response = self.session.put(_url, json=data, headers=headers)
            if _response.status_code in (405, 401):
                module_logger.info('Authorization........' + str(_response.status_code))
                self.logIn()
            elif _response.status_code == 204:
                module_logger.info('OK ..................' + str(_response.status_code))
                module_logger.debug('OK ..................' + str(_response.content))
                break
            else:
                module_logger.debug('ERROR...............' + str(_response.status_code))
                module_logger.debug('ERROR...............' + str(_response.content))
                break

    def putRequestAddComment(self):
        module_logger.info('PUT/EDIT add comment')
        _url = self.repairLink() + '/comment'
        _data = self.repairDATA()
        headers = {'Content-Type': 'application/json', 'Accept': 'application/json'}
        for timesReq in range(3):
            _response = self.session.post(_url, json=_data, headers=headers)
            if _response.status_code in (405, 401):
                module_logger.info('Authorization........' + str(_response.status_code))
                self.logIn()
            elif _response.status_code == 204:
                module_logger.info('OK ..................' + str(_response.status_code))
                module_logger.debug('OK ..................' + str(_response.content))
                break
            else:
                module_logger.debug('ERROR...............' + str(_response.status_code))
                break

    def putLinkIssue(self):
        pass

    # POST/CREATE
    def postRequest(self):
        module_logger.info('POST')
        _url = self.repairLink()
        _data = self.repairDATA()
        headers = {'Content-Type': 'application/json', 'Accept': 'application/json',
                   'Authorization': 'basicencodedauthheader'}
        for timesReq in range(3):
            _response = self.session.post(_url, json=_data, headers=headers)
            if _response.status_code == 401:
                module_logger.debug('Authorization........' + str(_response.status_code))
                self.logIn()
            elif _response.status_code == 201:
                module_logger.info('OK ..................' + str(_response.status_code))
                module_logger.debug('OK ..................' + str(_response.content))
                print(_response.content)
                with open('createJira.json', 'wb') as f:
                    f.write(_response.content)
                f.close()
                break
            else:
                module_logger.debug('ERROR...............' + str(_response.status_code))
                break
