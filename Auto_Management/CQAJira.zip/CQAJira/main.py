# URL_JIRA_LOGIN = 'https://rb-tracker.bosch.com/tracker/rb-login.jsp?'
# URL_JIRA = 'https://rb-tracker.bosch.com/tracker/rest/api/2/issue'
URL_JIRA_LOGIN = 'https://rb-tracker.bosch.com/tracker08/rb-login.jsp?'
URL_JIRA = 'https://rb-tracker.bosch.com/tracker08/rest/api/2/issue'
URL_CQA = 'http://si0bos201.de.bosch.com/cqweb/restapi/CQ2012prod/nprod/RECORD'

import Events
import logging

logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s %(levelname)-8s %(message)s',
                    datefmt='%a, %d %b %Y %H:%M:%S',
                    filename='log.log',
                    filemode='w',
                    )

# ------------------------------------------------------
# @argv1:  Server
# @argv2:  method
# @argv3:  recordID if it has
# @argv4:  userName, note in Jira browser will do that
# @argv5:  password, note in Jira browser will do that
# @argv6:  data as a dictionary if it has
# ------------------------------------------------------
if __name__ == '__main__':
    events = Events.Events()
    events.parseARGV()
