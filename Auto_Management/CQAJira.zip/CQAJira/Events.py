import CQA
import Jira
import logging

module_logger = logging.getLogger(__name__)


class Events:

    # Check character is a special
    @staticmethod
    def _chIsSpecial(_ch):
        _result = False
        if (not str.isalpha(_ch)) and (not str.isdigit(_ch)):  # and (not _ch.isnumeric()):
            _result = True
        return _result

    # Convert special character to Ascii
    # @staticmethod
    def toAsciiXML(self,_str):
        _wStr = ""
        for ch in _str:
            if self._chIsSpecial(ch):
                _wStr += "%" + str(format(ord(ch), "x"))
            else:
                _wStr += ch
        return _wStr

    # Find a key and its value in a complex dictionary
    # @staticmethod
    def findKeyInDict(self, key, dictionary):
        for k, v in dictionary.items():
            if k == key:
                yield v
            elif isinstance(v, dict):
                for result in self.findKeyInDict(key, v):
                    yield result
            elif isinstance(v, list):
                for d in v:
                    if isinstance(d, dict):
                        for result in self.findKeyInDict(key, d):
                            yield result

    # Parse command line
    @staticmethod
    def parseARGV():
        import argparse
        parser = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter,
                                         description='CQAnJIRA Interface')
        parser.add_argument('-s', '--server', type=str, required=True,
                            help='Server is CQA or JIRA')
        parser.add_argument('-m', '--methodReq', type=str, required=True,
                            help='method Request is GET or PUT or POST')
        parser.add_argument('-id', '--recordID', type=str, required=False, default=None,
                            help='ID of Issue or nprod')
        parser.add_argument('-usr', '--user', type=str, required=False, default=None,
                            help='User Name LogIn')
        parser.add_argument('-pwd', '--password', type=str, required=False, default=None,
                            help='Password LogIn')
        parser.add_argument('-d', '--data', type=str, required=False, default=None,
                            help='Data will send')

        args = parser.parse_args()

        ret = {'server': args.server,
               'methodReq': args.methodReq,
               'user': args.user,
               'password': args.password,
               'recordID': args.recordID,
               'data': args.data
               }
        if ret['server'] == 'CQA':
            module_logger.info('CQA......................')
            CQA.CQA(ret['methodReq'], ret['user'], ret['password'], ret['recordID'], ret['data'])
        else:
            module_logger.info('JIRA......................')
            Jira.Jira(ret['methodReq'], ret['recordID'], ret['data'])